package com.example.gachasummoninggame

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.random.Random

// Updated to include the image resource ID
data class GachaItem(val name: String, val rarity: Int, val imageRes: Int)

class GachaGameState {
    var tokens by mutableIntStateOf(40)
    var pity by mutableIntStateOf(0)

    var isShowingResults by mutableStateOf(false)
    var latestPullResults by mutableStateOf<List<GachaItem>>(emptyList())
    var totalInventory by mutableStateOf<List<GachaItem>>(emptyList())

    // 3-Star Pool (Mapped to your drawable names)
    private val pool3Star = listOf(
        GachaItem("Stick", 3, R.drawable.stick_sprite),
        GachaItem("Stone", 3, R.drawable.rock_sprite),
        GachaItem("Iron Ore", 3, R.drawable.iron_ore_sprite),
        GachaItem("Gold Ore", 3, R.drawable.gold_ore_sprite),
        GachaItem("Sapphire Ore", 3, R.drawable.sapphire_ore_sprite),
        GachaItem("Leaf", 3, R.drawable.leaf_sprite),
        GachaItem("Rope", 3, R.drawable.rope),
        GachaItem("Seed Pouch", 3, R.drawable.seed_pouch),
        // Add placeholders for items you haven't drawn yet
        GachaItem("Coal", 3, R.drawable.coal),
        GachaItem("Dirt", 3, R.drawable.dirt_sprite)
    )

    // 4-Star Pool
    private val pool4Star = listOf(
        GachaItem("Wood Log", 4, R.drawable.wood_log_sprite),
        GachaItem("Diamond", 4, R.drawable.diamond), // Using emerald as placeholder if diamond isn't drawn yet
        GachaItem("Emerald", 4, R.drawable.emerald),
        GachaItem("Amethyst", 4, R.drawable.amethyst)
    )

    fun pull(amount: Int) {
        if (tokens < amount) return

        tokens -= amount
        val currentResults = mutableListOf<GachaItem>()

        for (i in 1..amount) {
            pity++ // Adds 1 per pull (1, 5, or 10)
            val item = evaluateSinglePull()
            currentResults.add(item)

            // If a 5-star is pulled at ANY point in the sequence, reset to 0 instantly
            if (item.rarity == 5) pity = 0
        }

        // FIX: Add .toList() to ensure Compose detects the state change and shows the items
        latestPullResults = currentResults.toList()
        totalInventory = totalInventory + currentResults
        isShowingResults = true
    }

    private fun evaluateSinglePull(): GachaItem {
        // Hard Pity: 100% chance at 40 pulls
        if (pity >= 40) return getFiveStarItem()

        // Base 5-star chance is 2%
        var fiveStarChance = 2

        // Soft Pity: Starts at pull 30. Adds 10% chance per pull.
        if (pity >= 30) {
            val pullsIntoSoftPity = pity - 29
            fiveStarChance += pullsIntoSoftPity * 10
        }

        // Roll a number between 1 and 100
        val roll = Random.nextInt(1, 101)

        return when {
            // 5-Star check (Dynamic 2% to 100%)
            roll <= fiveStarChance -> getFiveStarItem()

            // 4-Star check (Always exactly an 8% window above the 5-star chance)
            roll <= fiveStarChance + 8 -> pool4Star.random()

            // 3-Star check (Whatever is left over)
            else -> pool3Star.random()
        }
    }

    private fun getFiveStarItem(): GachaItem {
        val wonFiftyFifty = Random.nextBoolean()
        return if (wonFiftyFifty) {
            GachaItem("Dragon Sword", 5, R.drawable.dragon_sword)
        } else {
            GachaItem("Standard Weapon", 5, R.drawable.standard_sword)
        }
    }

    fun restartGame() {
        tokens = 40
        pity = 0
        latestPullResults = emptyList()
        totalInventory = emptyList()
        isShowingResults = false
    }
}