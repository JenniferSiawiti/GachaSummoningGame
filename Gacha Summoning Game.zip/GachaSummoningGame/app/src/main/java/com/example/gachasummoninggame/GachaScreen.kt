package com.example.gachasummoninggame

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.window.Dialog
import androidx.compose.animation.animateColor
import androidx.compose.animation.core.*
import androidx.compose.foundation.clickable
import kotlinx.coroutines.delay
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.draw.scale
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Define your custom font family with both weights
val ObraLetraFont = FontFamily(
    Font(R.font.obra_letra, FontWeight.Normal),
    Font(R.font.obra_letra_bold, FontWeight.Bold)
)

// 1. The Entry Point
@Composable
fun GachaApp() {
    val gameState = remember { GachaGameState() }

    // Automatically applies Obra Letra to ALL text inside the app!
    ProvideTextStyle(value = LocalTextStyle.current.copy(fontFamily = ObraLetraFont)) {
        if (gameState.isShowingResults) {
            // FIX: Check if any item in the recent pull is a 5-star
            val hasFiveStar = gameState.latestPullResults.any { it.rarity == 5 }

            if (hasFiveStar) {
                // Route to the special animation!
                FiveStarRevealSequence(gameState)
            } else {
                // Standard grid for 3-star and 4-star pulls
                ResultScreen(gameState)
            }
        } else {
            MainGachaScreen(gameState)
        }
    }
}
// 2. The Banner Screen
@Composable
fun MainGachaScreen(gameState: GachaGameState) {
    // State variable to track if the restart pop-up should be visible
    var showRestartDialog by remember { mutableStateOf(false) }
    // NEW: State variable to track if the insufficient tokens pop-up should be visible
    var showInsufficientTokensDialog by remember { mutableStateOf(false) }

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.dungeon_background),
            contentDescription = "Background",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(start = 16.dp, end = 16.dp, bottom = 16.dp, top = 56.dp)
        ) {

            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color(0xFFE1F5FE),
                                    Color(0xFFB3E5FC)
                                )
                            ), RoundedCornerShape(50)
                        )
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Text(
                        "${gameState.tokens} tokens",
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }

                IconButton(
                    onClick = { showRestartDialog = true },
                    modifier = Modifier.background(Color(0x66000000), CircleShape)
                ) {
                    Text("↻", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Banner Area
            Box(modifier = Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(320.dp)
                        .padding(top = 16.dp)
                        .background(
                            brush = Brush.verticalGradient(
                                listOf(
                                    Color(0xFF223879).copy(alpha = 0.52f),
                                    Color(0xFF08FFCB).copy(alpha = 0.52f)
                                )
                            ),
                            shape = RoundedCornerShape(24.dp)
                        )
                        .border(
                            1.dp,
                            Color(0xFF08FFCB).copy(alpha = 0.8f),
                            RoundedCornerShape(24.dp)
                        )
                        .padding(16.dp)
                ) {
                    // 1. Top Left: Time Remaining
                    Text(
                        text = "Time Remaining:\n2 day(s) 13 hour(s) 30 minute(s)",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.align(Alignment.TopStart)
                    )

                    // 2. Middle/Left: The Sword Image
                    Image(
                        painter = painterResource(id = R.drawable.dragon_sword),
                        contentDescription = "Dragon Sword",
                        modifier = Modifier
                            .fillMaxSize(0.9f)
                            .align(Alignment.CenterStart)
                            .offset(x = (-55).dp, y = 15.dp)
                            .rotate(16.5f),
                        contentScale = ContentScale.Fit
                    )

                    // 3. Bottom Right: The Text Group
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(0.65f)
                            .align(Alignment.BottomEnd),
                        horizontalAlignment = Alignment.End
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("★★★★★ ", color = Color(0xFF8BC34A), fontSize = 16.sp)
                            Text(
                                "Dragon Sword",
                                color = Color(0xFFFFD54F),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "A legendary blade forged in the heart of an ancient dragon's flame. Its crimson edge burns with the fury of a thousand storms, while the soul of a forgotten dragon sleeps within its steel.",
                            color = Color.White,
                            fontSize = 10.sp,
                            lineHeight = 14.sp,
                            textAlign = TextAlign.Justify,
                            modifier = Modifier.offset(x = 20.dp, y = 5.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Event Duration: 09 Oct - 08 Nov",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Floating Pity Counter
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(end = 16.dp)
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color(0xFFE1F5FE),
                                    Color(0xFFB3E5FC)
                                )
                            ), RoundedCornerShape(50)
                        )
                        .border(1.dp, Color(0xFF9C27B0), RoundedCornerShape(50))
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Text(
                        "${gameState.pity} / 40 pity",
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            // Pull Buttons
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 32.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                // UPDATED: Buttons are always enabled, logic checks tokens on click
                AnimatedGachaButton(
                    text = "1 Pull",
                    enabled = true,
                    onClick = {
                        if (gameState.tokens >= 1) gameState.pull(1)
                        else showInsufficientTokensDialog = true
                    },
                    horizontalPadding = 24
                )

                AnimatedGachaButton(
                    text = "5 Pulls",
                    enabled = true,
                    onClick = {
                        if (gameState.tokens >= 5) gameState.pull(5)
                        else showInsufficientTokensDialog = true
                    },
                    horizontalPadding = 24
                )

                AnimatedGachaButton(
                    text = "10 Pulls",
                    enabled = true,
                    onClick = {
                        if (gameState.tokens >= 10) gameState.pull(10)
                        else showInsufficientTokensDialog = true
                    },
                    horizontalPadding = 20
                )
            }
        }

        // Restart Dialog using Custom Pixel Art
        if (showRestartDialog) {
            CustomImageDialog(
                title = "RESTART",
                message = "DO YOU WISH\nTO RESTART?",
                // The GREEN button (Left) is now YES, so it handles the restart
                onDismiss = {
                    gameState.restartGame()
                    showRestartDialog = false
                },
                // The RED button (Right) is now NO, so it just closes the pop-up
                onConfirm = { showRestartDialog = false },
                confirmText = "NO",   // Maps to the Right button
                dismissText = "YES",  // Maps to the Left button
                showDismissButton = true
            )
        }

        // Insufficient Tokens Dialog using Custom Pixel Art
        if (showInsufficientTokensDialog) {
            CustomImageDialog(
                title = "Insufficient Tokens",
                message = "You do not have enough tokens to perform this summon.",
                onDismiss = { showInsufficientTokensDialog = false },
                onConfirm = { showInsufficientTokensDialog = false },
                confirmText = "OK",
                showDismissButton = false // Hides the left button, making "OK" the only option
            )
        }
    }
}

// 3. The Result Screen Grid
@Composable
fun ResultScreen(gameState: GachaGameState) {
    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.dungeon_background),
            contentDescription = "Background",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0x99000000))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "Summon Results",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(top = 32.dp, bottom = 24.dp)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(gameState.latestPullResults) { item ->
                    val boxGradient = when (item.rarity) {
                        5 -> Brush.verticalGradient(listOf(Color(0xFFFFD54F), Color(0xFFFF8F00)))
                        4 -> Brush.verticalGradient(listOf(Color(0xFFBA68C8), Color(0xFF7B1FA2)))
                        else -> Brush.verticalGradient(listOf(Color(0xFF4FC3F7), Color(0xFF0288D1)))
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(100.dp)
                                .background(boxGradient, RoundedCornerShape(16.dp))
                                .border(2.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = item.imageRes),
                                contentDescription = item.name,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(8.dp),
                                contentScale = ContentScale.Fit
                            )
                        }

                        Text(
                            text = item.name,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            AnimatedGachaButton(
                text = "CLAIM",
                enabled = true,
                onClick = { gameState.isShowingResults = false },
                horizontalPadding = 48,
                modifier = Modifier.padding(bottom = 32.dp)
            )
        }
    }
}

// 4. Custom Animated Button
@Composable
fun AnimatedGachaButton(
    text: String,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    horizontalPadding: Int = 40
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // The animation logic: shrinks to 85% size when pressed, then bounces back
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.85f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "buttonBounce"
    )

    Button(
        onClick = onClick,
        enabled = enabled,
        interactionSource = interactionSource,
        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
        contentPadding = PaddingValues(),
        shape = RoundedCornerShape(50),
        modifier = modifier.scale(scale) // Applies the shrink/bounce effect
    ) {
        Box(
            modifier = Modifier
                .background(Brush.verticalGradient(listOf(Color(0xFFFFE082), Color(0xFFFFCA28))))
                .padding(horizontal = horizontalPadding.dp, vertical = 12.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(text, color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
    }
}

// 5. The 5-Star Reveal Animation Sequence
@Composable
fun FiveStarRevealSequence(gameState: GachaGameState) {
    // Get ALL 5-star items from the recent pull
    val fiveStarItems = remember(gameState.latestPullResults) {
        gameState.latestPullResults.filter { it.rarity == 5 }
    }

    // Track which 5-star we are currently revealing
    var currentRevealIndex by remember(gameState.latestPullResults) { mutableIntStateOf(0) }

    // Phase 0 = Flashing, Phase 1 = Golden Reveal, Phase 2 = Standard Result Grid
    var phase by remember(gameState.latestPullResults) { mutableIntStateOf(0) }

    // Timer for the flashing animation - UPDATED to re-trigger when phase changes back to 0
    LaunchedEffect(phase) {
        if (phase == 0) {
            delay(1500) // 1.5 seconds of flashing
            phase = 1
        }
    }

    when (phase) {
        0 -> {
            // Phase 0: Flashing Gold Screen
            val infiniteTransition = rememberInfiniteTransition(label = "flash")
            val color by infiniteTransition.animateColor(
                initialValue = Color.White,
                targetValue = Color(0xFFFFD54F), // Gold
                animationSpec = infiniteRepeatable(
                    animation = tween(200, easing = LinearEasing),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "colorFlash"
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(color)
            )
        }

        1 -> {
            // Safely get the current 5-star item based on our index
            val currentItem = fiveStarItems.getOrNull(currentRevealIndex)

            if (currentItem != null) {
                // Phase 1: Golden Reveal Screen
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color(0xFFFFD54F), Color(0xFFFF8F00))))
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) {
                            // CHECK FOR MORE 5-STARS
                            if (currentRevealIndex < fiveStarItems.size - 1) {
                                currentRevealIndex++ // Move to the next 5-star
                                phase = 0            // Flash the screen again to build hype!
                            } else {
                                phase = 2            // No more 5-stars, go to the final grid
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(horizontal = 24.dp)
                    ) {
                        Text(
                            text = if (currentItem.name == "Standard Weapon") "You Got A.." else "Congratulations, You Won",
                            color = Color.White,
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Image(
                            painter = painterResource(id = currentItem.imageRes),
                            contentDescription = currentItem.name,
                            modifier = Modifier.size(280.dp),
                            contentScale = ContentScale.Fit
                        )

                        Spacer(modifier = Modifier.height(24.dp))

                        Text("★★★★★", color = Color.White, fontSize = 32.sp)
                        Text(currentItem.name, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(48.dp))

                        Text(
                            text = "Click anywhere to continue",
                            color = Color.White.copy(alpha = 0.8f),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                // Safety fallback just in case the list is empty
                phase = 2
            }
        }

        2 -> {
            // Phase 2: Standard Result Grid showing all items pulled
            ResultScreen(gameState)
        }
    }
}

// 6. Custom Pixel Art Dialog
@Composable
fun CustomImageDialog(
    title: String,
    message: String,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit,
    confirmText: String = "Yes",
    dismissText: String = "No",
    showDismissButton: Boolean = true
) {
    Dialog(onDismissRequest = onDismiss) {
        // Master Box containing everything
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.width(320.dp)
        ) {
            // LAYER 1: Background Image
            Image(
                painter = painterResource(id = R.drawable.ru_sure_bg),
                contentDescription = "Dialog Background",
                modifier = Modifier
                    .fillMaxWidth()
                    .scale(scaleX = 1f, scaleY = if (showDismissButton) 1f else -1f),
                contentScale = ContentScale.FillWidth
            )

            // LAYER 2: Left Button Image (Green)
            if (showDismissButton) {
                Image(
                    painter = painterResource(id = R.drawable.button_kiri),
                    contentDescription = "Left Button Graphic",
                    modifier = Modifier.fillMaxWidth(),
                    contentScale = ContentScale.FillWidth
                )
            }

            // LAYER 3: Right Button Image (Red)
            if (showDismissButton) {
                Image(
                    painter = painterResource(id = R.drawable.button_kanan),
                    contentDescription = "Right Button Graphic",
                    modifier = Modifier.fillMaxWidth(),
                    contentScale = ContentScale.FillWidth
                )
            }

            // LAYER 4: The Text (Title & Message)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .matchParentSize()
                    .padding(horizontal = 24.dp)
            ) {
                // Only show the title if showDismissButton is true (i.e. Restart Dialog)
                if (showDismissButton) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = title,
                        color = Color(0xFFDDEDF8),
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.offset(y = 25.dp)
                    )
                }

                // Space before the main message
                Spacer(modifier = Modifier.height(if (showDismissButton) 40.dp else 24.dp))

                Text(
                    text = message,
                    // UPDATED: Now uses 0xFF334361 for both pop-up types
                    color = Color(0xFF334361),
                    fontSize = 30.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 30.sp,
                    modifier = Modifier.offset(y = if (showDismissButton) 40.dp else 80.dp)
                )
            }

            // LAYER 5: Clickable Zones and Button Text
            Row(modifier = Modifier.matchParentSize()) {
                // Left Clickable Half (Green Button)
                if (showDismissButton) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clickable(
                                interactionSource = remember { MutableInteractionSource() },
                                indication = null
                            ) { onDismiss() },
                        contentAlignment = Alignment.BottomCenter
                    ) {
                        Text(
                            text = dismissText,
                            color = Color(0xFFE1F8DD),
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            modifier = Modifier.offset(x = 13.dp, y = (-55).dp)
                        )
                    }
                }

                // Right Clickable Half (Red Button / OK Button)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null
                        ) { onConfirm() },
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Text(
                        text = confirmText,
                        // CHANGE THIS LINE: Use Color.White when showDismissButton is false
                        color = if (showDismissButton) Color(0xFF613333) else Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        modifier = Modifier.offset(
                            x = if (showDismissButton) (-8).dp else 0.dp,
                            y = if (showDismissButton) (-55).dp else (-37).dp
                        )
                    )
                }
            }
        }
    }
}

@Preview(
    showBackground = true,
    showSystemUi = true,
    device = "id:pixel_7"
)
@Composable
fun AppPreview() { // Renamed for clarity
    // Just call the main entry point, which handles all the routing!
    GachaApp()
}